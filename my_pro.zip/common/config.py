db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'root',
    'db': 'py_test',
    'charset': 'utf8'
}